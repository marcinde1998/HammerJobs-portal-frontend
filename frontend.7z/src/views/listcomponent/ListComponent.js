function ListComponent() {
    return (
        <div>
            <h2>Lista Komponentów</h2>
            <ul>
                <li>GL00001576823 regał: th7001</li>
                <li>GL00001576823 regał: th7002</li>
                <li>GL00001576823 regał: th7003</li>
                <li>GL00001576823 regał: th8001</li>
                <li>GL00001576823 regał: th8002</li>
                <li>GL00001576823 regał: th8003</li>
                <li>GL00001576823 regał: th6001</li>
                <li>GL00001576823 regał: th6002</li>
            </ul>
        </div>
    )
}
export default ListComponent;