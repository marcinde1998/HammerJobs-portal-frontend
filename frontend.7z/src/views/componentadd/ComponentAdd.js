function ComponentAdd() {
    return (
        <div>
            <h2>Dodaj Komponent</h2>
            <form>
                <input placeholder="nr zamówienia"></input>
                <input placeholder="index klienta"></input>
                <input placeholder="index wewnetrzny"></input>
                <input placeholder="index wewnetrzny"></input>
            </form>
        </div>
    )
}
export default ComponentAdd;